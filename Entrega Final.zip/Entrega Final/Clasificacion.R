# Para representar gráficamente la relación entre variables
library(ggplot2)
library(tidyr) #%>%
library(purrr) #map_dbl
require(GGally)
library(gridExtra) #grid.arrange
library(grid)  #grid.arrange
# Para clasificar con K-NN
library(class)
library(kknn)
library(GGally)
library(MASS)
library(ISLR)
library(klaR)
library(caret) 
library(gplots)
library(heplots)
library(MVN) #CrossTable
library(descr)
library(vcd) #V Cramer
library(knitr) #V Cramer
library(plyr)
library(nortest)
library(gridExtra)
library(dplyr)
library(PerformanceAnalytics)
library(PMCMR)
#cargamos el fichero de datos dentro de la variable dtC
dtC <- read.csv("led7digit/led7digit.dat", comment.char="@", header = FALSE)
n <- length(names(dtC)) - 1
names(dtC)[1:n] <- paste ("X", 1:n, sep="")
names(dtC)[n+1] <- "Y"
dtC %>% dim()
dtC %>% str()
dtC %>% summary()
map_dbl(dtC, .f = function(x){
  sum(is.na(x))
  })
dtC[ ,-8] <- lapply(dtC[ ,-8], as.numeric)
dtC$Y <- as.factor(dtC$Y) 

dtC %>% str()
dtC %>% summary()
crosstab(dtC$X1, dtC$Y, plot = FALSE, prop.c = TRUE, prop.t=TRUE, prop.r=TRUE, prop.chisq=FALSE,  emph.total = T)
ggplot(dtC, aes(factor(X1), fill = factor(Y))) + geom_bar()
chisq.test(table(dtC$Y, dtC$X1))
chisq.test(table(dtC$Y, dtC$X1))$stdres
assocstats(table(dtC$Y, dtC$X1))
multipleResultChi <- adply(combn(ncol(dtC),2), 2, function(x) {
  xi <- x[1]
  yi <- x[2]
  t <- table(dtC[, xi], dtC[, yi])
  test <- chisq.test(t)
  cramer <- assocstats(t)

  out <- data.frame(  "Row" = colnames(dtC)[xi]
                    , "Column" = colnames(dtC[yi])
                    ,  "chiCuadrado" = test$p.value
                    ,  "VCramer" = cramer$cramer
                    )
  return(out)
})
r <- filter(multipleResultChi, chiCuadrado < 0.05)
r[with(r, order(chiCuadrado, VCramer)), ]
run_knn_fold <- function(i, x, k, tt = "test") {
  file <- paste(x, "-10-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-10-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  #x_tra <- x_tra[,-c(7, 1)]
  #x_tst <- x_tst[,-c(7, 1)]
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  x_tra$Y <- as.factor(x_tra$Y)
  test$Y <- as.factor(test$Y)
  pred <- knn(x_tra[,1:In], k=k, test[,1:In], x_tra$Y)
  length(pred[pred==test[,ncol(test)]])/length(pred)
  
  #fitMulti=kknn(Y ~ . ,x_tra, test, k = k, kernel = c("optimal"))
  #yprime=fitMulti$fitted.values
  #sum(yprime ==  test[,8]) / length(test[,8]) #Calculate the accuracies.
  #sum(abs(test$Y-yprime)^2)/length(yprime) #RMSE Error cuadrático medio
}
compareK <- function(k, num_partitions, name, tt = "test") {
  mean(sapply(num_partitions, run_knn_fold, name, k, tt)) 
}
k <- 1:15 ## VALORES DE K QUE QUEREMOS PROBAR
tst.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "test") 
tra.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "train")
crossValidationResult <- cbind.data.frame("training" = tra.results, "testing" = tst.results, "k" = as.factor(k))

ggplot(crossValidationResult, aes(group = 1)) +
  geom_line(aes(x = k, y = training, color = "red")) +
  geom_line(aes(x = k, y = testing, color = "orange")) +
  xlab('K') +
  ylab('Acierto') +
  scale_color_discrete(name  ="Payer",
                          breaks=c("red", "orange"),
                          labels=c("Training", "testing"))
crossValidationResult.ordered <- crossValidationResult[order(-crossValidationResult$testing),]
crossValidationResult.ordered
base.accuracy <- crossValidationResult[order(-crossValidationResult$testing),]$testing[1]
base.k <- crossValidationResult[order(-crossValidationResult$testing),]$k[1]
#paste("Diferencia de porcentaje de acierto entre k = 15 y k = 11: ", crossValidationResult.ordered$testing[1] - #crossValidationResult.ordered$testing[2])
# Creamos las particiones para training y testing
set.seed(300)
indxTrain <- createDataPartition(y = dtC$Y,p = 0.5,list = FALSE)
training <- dtC[indxTrain,]
testing <- dtC[-indxTrain,]
prop.table(table(training$Y)) * 100
prop.table(table(dtC$Y)) * 100
set.seed(400)
#Configuro el entrenamiento para que sea una CV con 10-fold
ctrl <- trainControl(method="repeatedcv",repeats = 10)
knnFit <- train(x=training[,-8], y = training$Y, method = "knn", tuneLength = 20, trControl = ctrl)
knnFit
plot(knnFit)
#Get the confusion matrix to see accuracy value and other parameter values
knnPredict <- predict(knnFit,newdata = testing[,-8] )
confusionMatrix(knnPredict, testing$Y )
#CrossTable( x = knnPredict, y =  testing$Y, dnn = c("Predicción", "Real" ) )
knnPredict.accuracy = round(mean(knnPredict == testing$Y)*100,2)
knnPredict.accuracy
run_knn_fold <- function(i, x, k, c, tt = "test") {
  file <- paste(x, "-10-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-10-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  x_tra <- x_tra[,-c(7)]
  x_tst <- x_tst[,-c(7)]
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  x_tra$Y <- as.factor(x_tra$Y)
  test$Y <- as.factor(test$Y)
  pred <- knn(x_tra[,1:In], k=k, test[,1:In], x_tra$Y)
  length(pred[pred==test[,ncol(test)]])/length(pred)
}
# testing basic model = 0.7224490
tst.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "test") 
tra.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "train")
crossValidationResult <- cbind.data.frame("training" = tra.results, "testing" = tst.results, "k" = as.factor(k))
variación1.accuracy <- crossValidationResult[order(-crossValidationResult$testing),]$testing[1]
variación1.k <- crossValidationResult[order(-crossValidationResult$testing),]$k[1]
run_knn_fold <- function(i, x, k, tt = "test") {
  file <- paste(x, "-10-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-10-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  x_tra <- x_tra[,-c(1)]
  x_tst <- x_tst[,-c(1)]
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  x_tra$Y <- as.factor(x_tra$Y)
  test$Y <- as.factor(test$Y)
  pred <- knn(x_tra[,1:In], k=k, test[,1:In], x_tra$Y)
  length(pred[pred==test[,ncol(test)]])/length(pred)
}
# testing basic model = 0.7224490
tst.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "test") 
tra.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "train")
variación2.accuracy <- crossValidationResult[order(-crossValidationResult$testing),]$testing[1]
variación2.k <- crossValidationResult[order(-crossValidationResult$testing),]$k[1]
run_knn_fold <- function(i, x, k, tt = "test") {
  file <- paste(x, "-10-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-10-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  x_tra <- x_tra[,-c(1, 4)]
  x_tst <- x_tst[,-c(1, 4)]
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  x_tra$Y <- as.factor(x_tra$Y)
  test$Y <- as.factor(test$Y)
  pred <- knn(x_tra[,1:In], k=k, test[,1:In], x_tra$Y)
  length(pred[pred==test[,ncol(test)]])/length(pred)
}
# testing basic model = 0.7224490
tst.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "test") 
tra.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "train")
crossValidationResult <- cbind.data.frame("training" = tra.results, "testing" = tst.results, "k" = as.factor(k))
variación3.accuracy <- crossValidationResult[order(-crossValidationResult$testing),]$testing[1]
variación3.k <- crossValidationResult[order(-crossValidationResult$testing),]$k[1]
run_knn_fold <- function(i, x, k, tt = "test") {
  file <- paste(x, "-10-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-10-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  x_tra <- x_tra[,-c(7, 4)]
  x_tst <- x_tst[,-c(7, 4)]
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  x_tra$Y <- as.factor(x_tra$Y)
  test$Y <- as.factor(test$Y)
  pred <- knn(x_tra[,1:In], k=k, test[,1:In], x_tra$Y)
  length(pred[pred==test[,ncol(test)]])/length(pred)
  
  #fitMulti=kknn(Y ~ . ,x_tra, test, k = k, kernel = c("optimal"))
  #yprime=fitMulti$fitted.values
  #sum(yprime ==  test[,8]) / length(test[,8]) #Calculate the accuracies.
  #sum(abs(test$Y-yprime)^2)/length(yprime) #RMSE Error cuadrático medio
}
# testing basic model = 0.7224490
tst.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "test") 
tra.results <- sapply(k, compareK, 1:10, "led7digit/led7digit", "train")
crossValidationResult <- cbind.data.frame("training" = tra.results, "testing" = tst.results, "k" = as.factor(k))
variación4.accuracy <- crossValidationResult[order(-crossValidationResult$testing),]$testing[1]
variación4.k <- crossValidationResult[order(-crossValidationResult$testing),]$k[1]
models.accuracy <- c(base.accuracy, variación1.accuracy, variación2.accuracy, variación3.accuracy, variación4.accuracy)
models.k <- c(base.k, variación1.k, variación2.k, variación3.k, variación4.k)
models <- data.frame(models.accuracy, models.k)
row.names(models) <- c("Base", "Modificación 1","Modificación 2", "Modificación 3","Modificación 4")
models
mvn(data = dtC[,-8], mvnTest = "mardia")
mvn(data = dtC[, -8], mvnTest = "royston")
mvn(data = dtC[,-8], mvnTest = "hz")
boxM(dtC[, -8], dtC$Y)
ldaFit <- train(x=training[,-8], y = training$Y, method = "lda")
ldaPredict = predict(ldaFit, testing[,-8])
ldaPredict.accuracy = round(mean(ldaPredict == testing$Y)*100,2)
qdaFit <- train(Y ~ X1 + X2, data = training, method = "qda", trControl = ctrl)
qdaPredict = predict(qdaFit, testing[,-8])
qdaPredict.accuracy = round(mean(qdaPredict == testing$Y)*100,2)
data.frame("MODELO" = c("KNN", "QDA", "LDA"), "ACCURACY" = c(base.accuracy, ldaPredict.accuracy / 100, qdaPredict.accuracy / 100))
dtR <- read.csv("ANACALT/ANACALT.dat", comment.char="@", header = FALSE)
n <- length(names(dtR)) - 1
names(dtR)[1:n] <- paste ("X", 1:n, sep="")
names(dtR)[n+1] <- "Y"
dtR %>% dim()
dtR %>% str()
dtR[sample(1:nrow(dtR), 30, replace = FALSE),]
dtR %>% summary()
map_dbl(dtR, .f = function(x){
  sum(is.na(x))
  })
pairs(dtR[ ,c(1,6, 8)])
shapiro.test(dtR$X6)
shapiro.test(dtR$X1)
shapiro.test(dtR$Y)
round(cor(x = dtR[ ,c(1,6,8)], method = "spearman"), 3)
cor.test(x = dtR$X6, y = dtR$Y, method = "spearman", exact = F)
plot(dtR$X1)
TableFrec.X1<-table(dtR$X1)
freq_Acum <- cumsum(TableFrec.X1) #la frecuencia acumulada
freq_relat<- prop.table(TableFrec.X1)*100 #La frecuencia relativa en porcentaje
Freq_relat_acum<-cumsum(freq_relat) #La frecuencia relativa acumulada
cbind(TableFrec.X1,freq_Acum,freq_relat,Freq_relat_acum) #juntamos tod
crosstab(dtR$X1, dtR$Y, plot = FALSE, prop.c = TRUE, prop.t=TRUE, prop.r=TRUE, prop.chisq=FALSE,  emph.total = T)
modelo <- lm(dtR$Y ~ dtR$X1)
summary(modelo)
par(mfrow=c(2,2))
plot(modelo)
kruskal.test(Y ~ X1, data = dtR)
posthoc.kruskal.dunn.test(dtR$Y, dtR$X1, p.adjust.method = "holm")
with(dtR, prop.table(table(Y, X2), margin = 1))

TableFrec.X2<-table(dtR$X2)
freq_Acum <- cumsum(TableFrec.X2) #la frecuencia acumulada
freq_relat<- prop.table(TableFrec.X2)*100 #La frecuencia relativa en porcentaje
Freq_relat_acum<-cumsum(freq_relat) #La frecuencia relativa acumulada
cbind(TableFrec.X2,freq_Acum,freq_relat,Freq_relat_acum ) #juntamos todo

ggplot(data=data.frame(TableFrec.X2), aes(x=Var1, y=Freq)) + geom_bar(stat="identity") + ggtitle(" X2 vs Y")
fm <- lm(dtR$Y ~ dtR$X2)
summary(fm)
par(mfrow=c(2,2))
plot(fm)
shapiro.test(residuals(fm))
fligner.test(dtR$Y ~ dtR$X2, data = dtR)
TableFrec.X3<-table(dtR$X3)
freq_Acum <- cumsum(TableFrec.X3) #la frecuencia acumulada
freq_relat<- prop.table(TableFrec.X3)*100 #La frecuencia relativa en porcentaje
Freq_relat_acum<-cumsum(freq_relat) #La frecuencia relativa acumulada
cbind(TableFrec.X3,freq_Acum,freq_relat,Freq_relat_acum ) #juntamos todo

ggplot(data=data.frame(TableFrec.X3), aes(x=Var1, y=Freq)) + geom_bar(stat="identity") + ggtitle(" X3 vs Y")
crosstab(dtR$X3, dtR$Y, plot = FALSE, prop.c = TRUE, prop.t=TRUE, prop.r=TRUE, prop.chisq=FALSE,  emph.total = T)
TableFrec.X4<-table(dtR$X4)
freq_Acum <- cumsum(TableFrec.X4) #la frecuencia acumulada
freq_relat<- prop.table(TableFrec.X4)*100 #La frecuencia relativa en porcentaje
Freq_relat_acum<-cumsum(freq_relat) #La frecuencia relativa acumulada
cbind(TableFrec.X4,freq_Acum,freq_relat,Freq_relat_acum ) #juntamos todo

ggplot(data=data.frame(TableFrec.X4), aes(x=Var1, y=Freq)) + geom_bar(stat="identity") + ggtitle(" X4 vs Y")
crosstab(dtR$X4, dtR$Y, plot = FALSE, prop.c = TRUE, prop.t=TRUE, prop.r=TRUE, prop.chisq=FALSE,  emph.total = T)
fm <- lm(dtR$Y ~ dtR$X4)
summary(fm)
par(mfrow=c(2,2))
plot(fm)
TableFrec.X5<-table(dtR$X5)
freq_Acum <- cumsum(TableFrec.X5) #la frecuencia acumulada
freq_relat<- prop.table(TableFrec.X5)*100 #La frecuencia relativa en porcentaje
Freq_relat_acum<-cumsum(freq_relat) #La frecuencia relativa acumulada
cbind(TableFrec.X5,freq_Acum,freq_relat,Freq_relat_acum ) #juntamos todo

ggplot(data=data.frame(TableFrec.X5), aes(x=Var1, y=Freq)) + geom_bar(stat="identity") + ggtitle(" X5 vs Y")
crosstab(dtR$X5, dtR$Y, plot = FALSE, prop.c = TRUE, prop.t=TRUE, prop.r=TRUE, prop.chisq=FALSE,  emph.total = T)
fm <- lm(dtR$Y ~ dtR$X5)
summary(fm)
par(mfrow=c(2,2))
plot(fm)
TableFrec.X7<-table(dtR$X7)
freq_Acum <- cumsum(TableFrec.X7) #la frecuencia acumulada
freq_relat<- prop.table(TableFrec.X7)*100 #La frecuencia relativa en porcentaje
Freq_relat_acum<-cumsum(freq_relat) #La frecuencia relativa acumulada
cbind(TableFrec.X7,freq_Acum,freq_relat,Freq_relat_acum ) #juntamos todo

ggplot(data=data.frame(TableFrec.X7), aes(x=Var1, y=Freq)) + geom_bar(stat="identity") + ggtitle(" X7 vs Y")
crosstab(dtR$X7, dtR$Y, plot = FALSE, prop.c = TRUE, prop.t=TRUE, prop.r=TRUE, prop.chisq=FALSE,  emph.total = T)
fm <- lm(dtR$Y ~ dtR$X7)
summary(fm)
par(mfrow=c(2,2))
plot(fm)
run_lm_fold <- function(i, model, x, tt = "test") {
  file <- paste(x, "-5-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-5-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  # x_tra$Y <- as.factor(x_tra$Y)
  # test$Y <- as.factor(test$Y)
  # modela <- lda(model, data=x_tra)
  # pred <- predict(modela, test)
  # length(pred[pred$class==test[,ncol(test)]])/length(pred$class)
  
  fitMulti=lm(model,x_tra)
  yprime=predict(fitMulti,test)
  sum(abs(test$Y-yprime)^2)/length(yprime) ##MSE
}
lmMSEtrain <- c()
lmMSEtest <- c()
#lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X1 ,"ANACALT/ANACALT","train")))
#lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X1,"ANACALT/ANACALT","test")))

lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X2 ,"ANACALT/ANACALT","train")))
lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X2,"ANACALT/ANACALT","test")))

lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X3,"ANACALT/ANACALT","train")))
lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X4,"ANACALT/ANACALT","test")))

#lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X4,"ANACALT/ANACALT","train")))
#lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X4,"ANACALT/ANACALT","test")))

#lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X5,"ANACALT/ANACALT","train")))
#lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X5,"ANACALT/ANACALT","test")))

lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X6,"ANACALT/ANACALT","train")))
lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X6,"ANACALT/ANACALT","test")))

lmMSEtrain<- c(lmMSEtrain, mean(sapply(1:5,run_lm_fold,Y~X7,"ANACALT/ANACALT","train")))
lmMSEtest<- c(lmMSEtest, mean(sapply(1:5,run_lm_fold, Y~X7,"ANACALT/ANACALT","test")))

crossValidationRegresionResult <- data.frame(lmMSEtest, lmMSEtrain)
row.names(crossValidationRegresionResult) <- c("X2", "X3", "X6", "X7") 
names(crossValidationRegresionResult) <- c("lmMSEtest RMSE", "lmMSEtrain RMSE")
crossValidationRegresionResult.ordered <- crossValidationRegresionResult[order(crossValidationRegresionResult$lmMSEtrain),]
crossValidationRegresionResult.ordered
model.base <- lm(Y~ ., data=dtR)
summary(model.base)
model.base.modificacion.2 <- lm(Y~. -X4, data=dtR)
summary(model.base.modificacion.2)
model.base.modificacion.3 <- lm(Y~. -X4-X5, data=dtR)
summary(model.base.modificacion.3)
model.base.modificacion.4 <- lm(Y~. -X4-X5-X1, data=dtR)
summary(model.base.modificacion.4)
model.base.modificacion.5 <- lm(Y~. -X4-X5-X7, data=dtR)
summary(model.base.modificacion.5)
dtR.dummy <- dtR
dtR.dummy$X1 <- ifelse(dtR.dummy$X1 != 0, 1, 0)

model.base.modificacion.3.1 <- lm(Y~. -X4-X5-X7, data=dtR.dummy)
summary(model.base.modificacion.3.1)
modificacion.lmMSEtrain <- c()
modificacion.lmMSEtest <- c()
modificacion.modelName <- c()
modificacion.rSquared <- c()

run_lm_fold_dummy <- function(i, model, x, tt = "test") {
  file <- paste(x, "-5-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-5-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  x_tra$X1 <- ifelse(x_tra$X1 != 0, 1, 0)
  x_tst$X1 <- ifelse(x_tst$X1 != 0, 1, 0)
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  #x_tra$Y <- as.factor(x_tra$Y)
  #test$Y <- as.factor(test$Y)
  #modela <- lda(model, data=x_tra)
  #pred <- predict(modela, test)
  #length(pred[pred$class==test[,ncol(test)]])/length(pred$class)
  
  fitMulti=lm(model,x_tra)
  yprime=predict(fitMulti,test)
  sum(abs(test$Y-yprime)^2)/length(yprime) ##MSE
}

modificacion.lmMSEtrain<- c(modificacion.lmMSEtrain, mean(sapply(1:5,run_lm_fold_dummy,Y~.-X4-X5-X7,"ANACALT/ANACALT","train")))
modificacion.lmMSEtest<- c(modificacion.lmMSEtest, mean(sapply(1:5,run_lm_fold_dummy, Y~.-X4-X5-X7,"ANACALT/ANACALT","test")))
modificacion.modelName<- c(modificacion.modelName, "model.base.modificacion.3.1")
modificacion.rSquared <- c(modificacion.rSquared, summary(model.base.modificacion.3.1)$adj.r.squared)
dtR.age <- dtR.dummy
dtR.age$X6 <- cut(dtR.age$X6, breaks = seq(1950, 1990, by = 10), dig.lab = 4, right = TRUE)
model.base.modificacion.3.2 <- lm(Y~. -X4-X5-X7, data=dtR.age)
summary(model.base.modificacion.3.2)
run_lm_fold_dummy_range <- function(i, model, x, tt = "test") {
  file <- paste(x, "-5-", i, "tra.dat", sep="")
  x_tra <- read.csv(file, comment.char="@")
  file <- paste(x, "-5-", i, "tst.dat", sep="")
  x_tst <- read.csv(file, comment.char="@")
  In <- length(names(x_tra)) - 1
  names(x_tra)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tra)[In+1] <- "Y"
  names(x_tst)[1:In] <- paste ("X", 1:In, sep="")
  names(x_tst)[In+1] <- "Y"
  x_tra$X1 <- ifelse(x_tra$X1 != 0, 1, 0)
  x_tst$X1 <- ifelse(x_tst$X1 != 0, 1, 0)
  x_tra$X6 <- cut(x_tra$X6, breaks = seq(1950, 1990, by = 10), dig.lab = 4, right = TRUE)
  x_tst$X6 <- cut(x_tst$X6, breaks = seq(1950, 1990, by = 10), dig.lab = 4, right = TRUE)
  if (tt == "train") {
    test <- x_tra
  }
  else {
   test <- x_tst
  }
  x_tra$Y <- as.factor(x_tra$Y)
  test$Y <- as.factor(test$Y)
  modela <- lda(model, data=x_tra)
  pred <- predict(modela, test)
  length(pred[pred$class==test[,ncol(test)]])/length(pred$class)
#Devolvemos el acierto length(pred[pred$class==test[,ncol(test)]])/length(pred$class)

  #fitMulti=lm(model,data = x_tra)
  #yprime=predict(fitMulti,test)
  #sum(abs(test$Y-yprime)^2)/length(yprime) ##MSE
}

modificacion.lmMSEtrain<- c(modificacion.lmMSEtrain, mean(sapply(1:5,run_lm_fold_dummy_range,Y~.-X4-X5-X7,"ANACALT/ANACALT","train")))
modificacion.lmMSEtest<- c(modificacion.lmMSEtest, mean(sapply(1:5,run_lm_fold_dummy_range, Y~.-X4-X5-X7,"ANACALT/ANACALT","test")))
modificacion.modelName<- c(modificacion.modelName, "model.base.modificacion.3.2")
modificacion.rSquared <- c(modificacion.rSquared, summary(model.base.modificacion.3.2)$adj.r.squared)
#modificacion.lmMSEtest
modelo_sinPol <- lm(dtR$Y ~ dtR$X6)
summary(modelo_sinPol)
plot(x = dtR$X6, y = dtR$Y, main = "dtR$Y ~ dtR$X6", pch = 20, col = "grey30")
abline(modelo_sinPol, lwd = 3, col = "red")

modelo_pol2 <- lm(dtR$Y ~ poly(dtR$X6, 5))
summary(modelo_pol2)
plot(x = dtR$X6, y = dtR$Y, main = "dtR$Y ~ poly(dtR$X6, 5)", pch = 20, col = "grey30")
points(dtR$X6, fitted(modelo_pol2), col = 'red', pch = 20)
anova(modelo_sinPol, modelo_pol2)
dtR.poly <- dtR.dummy
model.base.modificacion.3.3 <- lm(Y~. -X4-X5-X7-X6+poly(dtR$X6, 5), data=dtR.poly)
summary(model.base.modificacion.3.3)
modificacion.lmMSEtrain<- c(modificacion.lmMSEtrain, mean(sapply(1:5,run_lm_fold_dummy,Y~.-X4-X5-X7-X6+poly(X6, 5),"ANACALT/ANACALT","train")))
modificacion.lmMSEtest<- c(modificacion.lmMSEtest, mean(sapply(1:5,run_lm_fold_dummy, Y~.-X4-X5-X7-X6+poly(X6, 5),"ANACALT/ANACALT","test")))
modificacion.modelName<- c(modificacion.modelName, "model.base.modificacion.3.3")
modificacion.rSquared <- c(modificacion.rSquared, summary(model.base.modificacion.3.3)$adj.r.squared)
model.base.modificacion.3.4 <- lm(Y~X1+poly(dtR$X6, 5), data=dtR.poly)
summary(model.base.modificacion.3.4)
modificacion.lmMSEtrain<- c(modificacion.lmMSEtrain, mean(sapply(1:5,run_lm_fold_dummy,Y~X1+poly(X6, 5),"ANACALT/ANACALT","train")))
modificacion.lmMSEtest<- c(modificacion.lmMSEtest, mean(sapply(1:5,run_lm_fold_dummy, Y~X1+poly(X6, 5),"ANACALT/ANACALT","test")))
modificacion.modelName<- c(modificacion.modelName, "model.base.modificacion.3.4")
modificacion.rSquared <- c(modificacion.rSquared, summary(model.base.modificacion.3.4)$adj.r.squared)
cbind("modelo" = modificacion.modelName,"MSEtest" = modificacion.lmMSEtest,"MSEtrain" = modificacion.lmMSEtrain,"R Squared" = modificacion.lmMSEtrain) #juntamos tod
multipleResultChi <- adply(combn(ncol(dtR[ ,-c(1,6,8)]),2), 2, function(x) {
  xi <- x[1]
  yi <- x[2]
  t <- table(dtC[, xi], dtC[, yi])
  test <- chisq.test(t)
  cramer <- assocstats(t)

  out <- data.frame(  "Row" = colnames(dtC)[xi]
                    , "Column" = colnames(dtC[yi])
                    ,  "chiCuadrado" = test$p.value
                    ,  "VCramer" = cramer$cramer
                    )
  return(out)
})
r <- filter(multipleResultChi, chiCuadrado < 0.05)
r[with(r, order(chiCuadrado, VCramer)), ]
dtR.int.1 <- dtR.dummy
model.base.modificacion.3.3.1 <- lm(Y~X1+X2*X4+poly(dtR$X6, 5), data=dtR.poly)
summary(model.base.modificacion.3.3.1)
dtR.int.1 <- dtR.dummy
model.base.modificacion.3.3.2 <- lm(Y~X1+X2*X3+poly(dtR$X6, 5), data=dtR.poly)
summary(model.base.modificacion.3.3.1)
dtR.int.1 <- dtR.dummy
model.base.modificacion.3.3.3 <- lm(Y~X1+X2*X5+poly(dtR$X6, 5), data=dtR.poly)
summary(model.base.modificacion.3.3.1)
## NA
## 
